-- Profitmancer: one line of crafting / auction house info in item tooltips (hold Shift for the details).
-- Prices come from ProfitmancerData.lua (hourly cloud scan, refreshed by the Profitmancer updater; loaded at login or /reload)
-- and from Auctionator's own scans when they are fresher.
local ADDON = ...
local S = ProfitmancerStatic or { rec = {}, vend = { H = {}, A = {} }, npc = { H = {}, A = {} }, bm = {}, profs = {} }
local FR = GetLocale() == "frFR"

local L = FR and {
	perDay = "/j", vendor = "PNJ", vendorL = "PNJ", ahL = "HV", craftL = "Craft", buy = "(achat)", sell = "(rachat)", notListed = "pas en vente à l'HV", emv = "Prix marché (EMV)", low = "Plus bas", listed = "En vente",
	sold = "Vendus 24 h", craft = "Coût du craft", profit = "Profit / craft", usedIn = "Utilisé dans", recipes = "recettes",
	best = "Meilleur usage", buyAt = "Acheter chez", cheaper = "moins cher qu'à l'HV", source = "Source", cloud = "cloud",
	ago = "il y a", today = "scan d'aujourd'hui", days = "j", hours = "h", min = "min", noData = "Aucune donnée de prix : lance le programme de mise à jour de Profitmancer ou fais un scan Auctionator.",
	profs = { alch = "Alchimie", cook = "Cuisine", bs = "Forge", lw = "Travail du cuir", tail = "Couture", eng = "Ingénierie", ench = "Enchantement", mine = "Minage", fa = "Secourisme" },
	help = "/pfm : état des données · /pfm detail : toujours afficher le détail · /pfm off|on",
} or {
	perDay = "/day", vendor = "Vendor", vendorL = "Vendor", ahL = "AH", craftL = "Craft", buy = "(buy)", sell = "(sell)", notListed = "not listed on the AH", emv = "Market (EMV)", low = "Lowest", listed = "Listed",
	sold = "Sold 24h", craft = "Craft cost", profit = "Profit / craft", usedIn = "Used in", recipes = "recipes",
	best = "Best use", buyAt = "Buy from", cheaper = "cheaper than the AH", source = "Source", cloud = "cloud",
	ago = "", today = "today's scan", days = "d", hours = "h", min = "min", noData = "No price data: run the Profitmancer updater or do an Auctionator scan.",
	profs = {},
	help = "/pfm: data status · /pfm detail: always show the details · /pfm off|on",
}

ProfitmancerDB = ProfitmancerDB or {}

-- ——— Indexes built once from the static data ———
local byProduct, usedIn = {}, {}
for _, r in ipairs(S.rec) do
	local id = r[1]
	byProduct[id] = byProduct[id] or {}
	table.insert(byProduct[id], r)
	for _, x in ipairs(r[5]) do
		usedIn[x[1]] = usedIn[x[1]] or {}
		table.insert(usedIn[x[1]], r)
	end
end

local function faction()
	return UnitFactionGroup("player") == "Alliance" and "A" or "H"
end

-- ——— Prices: cloud file first while it is recent, Auctionator's scan of today otherwise ———
local function auctionator(id)
	local api = Auctionator and Auctionator.API and Auctionator.API.v1
	if not (api and api.GetAuctionPriceByItemID) then return nil end
	local ok, p = pcall(api.GetAuctionPriceByItemID, ADDON, id)
	if not ok or type(p) ~= "number" then return nil end
	local okA, age = pcall(api.GetAuctionAgeByItemID, ADDON, id)
	return p, okA and type(age) == "number" and age or nil
end

local function price(id)
	local D = ProfitmancerData
	local c = D and D.p and D.p[id]
	local cloudAge = D and D.t and (time() - D.t) or nil
	local ap, aage = auctionator(id)
	if c and (cloudAge < 6 * 3600 or not ap or (aage and aage > 0)) then
		return { emv = c[1], min = c[2], qty = c[3], sold = c[4] >= 0 and c[4] or nil, src = "cloud", age = cloudAge }
	end
	if ap then
		return { emv = ap, min = ap, qty = c and c[3] or nil, sold = c and c[4] >= 0 and c[4] or nil, src = "auctionator", days = aage }
	end
	if c then return { emv = c[1], min = c[2], qty = c[3], sold = c[4] >= 0 and c[4] or nil, src = "cloud", age = cloudAge } end
	return nil
end

local function vendorBuy(id) return S.vend[faction()][id] end

-- Reagent cost: the cheaper of the vendor and the AH
local function cost(id)
	local v, p = vendorBuy(id), price(id)
	local a = p and p.emv
	if v and (not a or v <= a) then return v, "vendor" end
	return a, "ah"
end

-- Cheapest known way to craft one item (cost per item made), with the recipe used
local function craftCost(id)
	local best, bestRec
	for _, r in ipairs(byProduct[id] or {}) do
		local total, ok = 0, true
		for _, x in ipairs(r[5]) do
			local c = cost(x[1])
			if not c then ok = false break end
			total = total + c * x[2]
		end
		if ok then
			total = total / math.max(1, r[4])
			if not best or total < best then best, bestRec = total, r end
		end
	end
	return best, bestRec or (byProduct[id] and byProduct[id][1])
end

-- ——— Formatting ———
local G, SI, CO = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:1:0|t", "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:1:0|t", "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:1:0|t"
local function money(c, signed)
	if not c then return "?" end
	local sign = ""
	if signed then sign = c < 0 and "-" or "+" end
	c = math.floor(math.abs(c) + 0.5)
	local g, s, cp = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
	if g > 0 then return sign .. g .. G .. (s > 0 and (" " .. s .. SI) or "") end -- gold: copper is noise
	if s > 0 then return sign .. s .. SI .. (cp > 0 and (" " .. cp .. CO) or "") end
	return sign .. cp .. CO
end
local function ageText(p)
	if p.src == "auctionator" then
		if p.days == 0 then return "Auctionator · " .. L.today end
		return "Auctionator · " .. (p.days and ((FR and L.ago .. " " or "") .. p.days .. " " .. L.days) or "?")
	end
	local a = p.age or 0
	local t = a < 3600 and (math.floor(a / 60) .. " " .. L.min) or a < 172800 and (math.floor(a / 3600) .. " " .. L.hours) or (math.floor(a / 86400) .. " " .. L.days)
	return L.cloud .. " · " .. ((ProfitmancerData and ProfitmancerData.ah) or "?") .. " · " .. (FR and (L.ago .. " " .. t) or (t .. " ago"))
end
local PURPLE, GREEN, RED, GREY, YEL, BLUE = 0.71, { 0.12, 1, 0 }, { 1, 0.35, 0.29 }, { 0.62, 0.62, 0.62 }, { 1, 0.82, 0 }, { 0.44, 0.84, 1 }

local WHITE = { 1, 1, 1 }
local function sideLine(tt, left, right, col)
	tt:AddDoubleLine(left, right, 0.71, 0.55, 1, col[1], col[2], col[3])
end
local function addLine(tt, right, col)
	tt:AddDoubleLine("Profitmancer", right, PURPLE, 0.55, 1, col[1], col[2], col[3])
end
local function detail(tt, left, right, col)
	col = col or { 1, 1, 1 }
	tt:AddDoubleLine("  " .. left, right, YEL[1], YEL[2], YEL[3], col[1], col[2], col[3])
end

-- ——— The tooltip ———
local function addInfo(tt, id)
	if not id or ProfitmancerDB.off then return end
	local p = price(id)
	local isProduct = byProduct[id] ~= nil
	local isReagent = usedIn[id] ~= nil
	local vb = vendorBuy(id)
	if not p and not isProduct and not isReagent and not vb then return end
	local perDay = p and p.sold and (" |cff9d9d9d· " .. p.sold .. L.perDay .. "|r") or ""

	-- Three short lines, in this order: vendor price, auction house price, craft cost (with the profit)
	local cc, rec = nil, nil
	if isProduct then cc, rec = craftCost(id) end
	-- 1. Vendor: what an NPC sells it for (green when cheaper than the AH), else what an NPC pays you for it
	if vb then
		sideLine(tt, L.vendorL, money(vb) .. " |cff9d9d9d" .. L.buy .. "|r", (p and p.emv and vb < p.emv) and GREEN or WHITE)
	else
		local sell = select(11, GetItemInfo(id))
		if sell and sell > 0 then sideLine(tt, L.vendorL, money(sell) .. " |cff9d9d9d" .. L.sell .. "|r", WHITE) end
	end
	-- 2. Auction house: market price (EMV) and sales per day
	if p then sideLine(tt, L.ahL, money(p.emv) .. perDay, WHITE)
	else sideLine(tt, L.ahL, L.notListed, GREY) end
	-- 3. Craft: cost of one craft, then the profit when it is sold at the AH
	if isProduct then
		if cc and p and p.emv then
			local pr = p.emv - cc
			local pct = cc > 0 and math.floor(pr / cc * 100 + 0.5) or 0
			local c = pr >= 0 and "|cff1eff00" or "|cffff5a4a"
			sideLine(tt, L.craftL, money(cc) .. "  " .. c .. money(pr, true) .. " (" .. (pct >= 0 and "+" or "") .. pct .. "%)|r", WHITE)
		elseif cc then sideLine(tt, L.craftL, money(cc), WHITE)
		end
	end

	-- Details with Shift
	if not (IsShiftKeyDown() or ProfitmancerDB.detail) then return end
	if p then
		if p.min and p.min ~= p.emv then detail(tt, L.low, money(p.min)) end
		if p.qty then detail(tt, L.listed, tostring(p.qty)) end
		if p.sold then detail(tt, L.sold, "~" .. p.sold) end
	end
	if isProduct then
		if rec then
			local prof = L.profs[rec[2]] or S.profs[rec[2]] or rec[2]
			tt:AddLine("  " .. prof .. " " .. rec[3], GREY[1], GREY[2], GREY[3])
		end
	end
	if vb then
		local n = S.npc[faction()][id]
		local more = p and p.emv and vb < p.emv and (" (" .. L.cheaper .. ")") or ""
		detail(tt, L.vendor, money(vb) .. more, GREEN)
		if n then tt:AddLine("  " .. L.buyAt .. " " .. n[1] .. " · " .. n[2] .. " " .. n[3] .. ", " .. n[4], BLUE[1], BLUE[2], BLUE[3]) end
	end
	if isReagent then
		local list, bestName, bestPr = usedIn[id], nil, nil
		for _, r in ipairs(list) do
			local c = craftCost(r[1]); local q = price(r[1])
			if c and q and q.emv then
				local pr = q.emv - c
				if not bestPr or pr > bestPr then bestPr, bestName = pr, r[1] end
			end
		end
		detail(tt, L.usedIn, #list .. " " .. L.recipes)
		if bestName then
			local name = GetItemInfo(bestName) or ("#" .. bestName)
			tt:AddLine("  " .. L.best .. ": " .. name .. " (" .. money(bestPr, true) .. ")", GREY[1], GREY[2], GREY[3])
		end
	end
	if p then tt:AddLine("  " .. L.source .. ": " .. ageText(p), GREY[1], GREY[2], GREY[3]) end
end

local function itemIdOf(tt, data)
	if data and data.id and data.type == (Enum.TooltipDataType and Enum.TooltipDataType.Item) then return data.id end
	local _, link = tt:GetItem()
	return link and tonumber(link:match("item:(%d+)"))
end

if TooltipDataProcessor and Enum.TooltipDataType then
	TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
		if tt == GameTooltip or tt == ItemRefTooltip or (tt.GetName and tt:GetName() and tt:GetName():find("^ShoppingTooltip")) then
			addInfo(tt, itemIdOf(tt, data))
		end
	end)
else
	for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
		tt:HookScript("OnTooltipSetItem", function(self) addInfo(self, itemIdOf(self)) end)
	end
end

-- Shift pressed or released: redraw the tooltip so the details appear / disappear
local f = CreateFrame("Frame")
f:RegisterEvent("MODIFIER_STATE_CHANGED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, ev, key)
	if ev == "PLAYER_LOGIN" then
		if not ProfitmancerData and not (Auctionator and Auctionator.API) then print("|cffb48cffProfitmancer|r: " .. L.noData) end
		return
	end
	if (key == "LSHIFT" or key == "RSHIFT") and GameTooltip:IsShown() and GameTooltip:GetItem() then
		if GameTooltip.RefreshData then pcall(GameTooltip.RefreshData, GameTooltip)
		else
			local owner = GameTooltip:GetOwner()
			if owner and owner:GetScript("OnEnter") then owner:GetScript("OnEnter")(owner) end
		end
	end
end)

SLASH_PROFITMANCER1 = "/profitmancer"
SLASH_PROFITMANCER2 = "/pfm"
SlashCmdList.PROFITMANCER = function(msg)
	msg = (msg or ""):lower()
	if msg == "off" then ProfitmancerDB.off = true
	elseif msg == "on" then ProfitmancerDB.off = nil
	elseif msg == "detail" then ProfitmancerDB.detail = not ProfitmancerDB.detail
	end
	local D = ProfitmancerData
	local n = 0
	if D and D.p then for _ in pairs(D.p) do n = n + 1 end end
	print("|cffb48cffProfitmancer|r: " .. (D and (n .. " prices · " .. (D.ah or "?") .. " · " .. date("%d/%m %H:%M", D.t)) or L.noData)
		.. (ProfitmancerDB.off and " · OFF" or "") .. (ProfitmancerDB.detail and " · detail" or ""))
	print(L.help)
end
