-- Profitmancer: history of the items you sold at the auction house, in a panel docked to the auction house window.
-- A plain button under the auction house opens it (Blizzard's own tabs are left alone, so buying never gets blocked).
-- /pfm sales opens it anywhere.
local FR = GetLocale() == "frFR"
local T = FR and {
	btn = "Ventes", btnTip = "Historique de tes ventes à l'hôtel des ventes : total, meilleures ventes, recherche.", title = "Profitmancer · historique des ventes", search = "Rechercher",
	p1 = "24 h", p7 = "7 j", p30 = "30 j", pAll = "Tout",
	total = "Total", nSales = "%d vente(s)", avg = "moyenne %s / vente", best = "Meilleure vente",
	empty = "Aucune vente sur cette période. Les ventes sont enregistrées quand tu récupères l'or des courriers « Vente réussie ».",
	each = "l'unité", rows = "%d–%d sur %d", wheel = "Molette pour défiler",
} or {
	btn = "Sales", btnTip = "History of your auction house sales: totals, best sellers, search.", title = "Profitmancer · sales history", search = "Search",
	p1 = "24 h", p7 = "7 d", p30 = "30 d", pAll = "All",
	total = "Total", nSales = "%d sale(s)", avg = "average %s / sale", best = "Best seller",
	empty = "No sale in this period. Sales are recorded when you take the gold from \"Auction successful\" mails.",
	each = "each", rows = "%d–%d of %d", wheel = "Mouse wheel to scroll",
}
local G, SI, CO = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:1:0|t", "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:1:0|t", "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:1:0|t"
local function money(c)
	c = math.floor(math.abs(c or 0) + 0.5)
	local g, s, cp = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
	if g > 0 then return g .. G .. (s > 0 and (" " .. s .. SI) or "") end
	if s > 0 then return s .. SI .. (cp > 0 and (" " .. cp .. CO) or "") end
	return cp .. CO
end
local function when(t)
	local d = time() - t
	if d < 3600 then return math.max(1, math.floor(d / 60)) .. " min" end
	if d < 86400 then return math.floor(d / 3600) .. " h" end
	return date(FR and "%d/%m" or "%m/%d", t)
end

local panel, rows, ROWS, ROW_H, MAXROWS = nil, {}, 16, 30, 20
local state = { period = 7, query = "", offset = 0 }
local list = {}

local function host() return AuctionHouseFrame or AuctionFrame end
local ahBtn, styleBtn -- the Sales button (defined further down)

local function filtered()
	local out, now, q = {}, time(), state.query:lower()
	local min = state.period > 0 and (now - state.period * 86400) or 0
	for _, s in ipairs(ProfitmancerGains and ProfitmancerGains.log() or {}) do
		if s[4] >= min and (q == "" or tostring(s[1]):lower():find(q, 1, true)) then out[#out + 1] = s end
	end
	return out
end

local function render()
	if not panel or not panel:IsShown() then return end
	list = filtered()
	local total, byItem = 0, {}
	for _, s in ipairs(list) do
		total = total + s[2]
		local b = byItem[s[1]] or { n = 0, sum = 0 }
		b.n, b.sum = b.n + 1, b.sum + s[2]
		byItem[s[1]] = b
	end
	local bestName, best = nil, nil
	for n, b in pairs(byItem) do if not best or b.sum > best.sum then bestName, best = n, b end end
	panel.sum1:SetText(T.total .. " : |cff3ec46d" .. money(total) .. "|r  ·  " .. T.nSales:format(#list))
	panel.sum2:SetText(#list > 0 and (T.avg:format(money(total / #list)) .. (bestName and ("  ·  " .. T.best .. " : " .. bestName .. " (" .. money(best.sum) .. ")") or "")) or "")
	state.offset = math.max(0, math.min(state.offset, #list - ROWS))
	for i = 1, ROWS do
		local r, s = rows[i], list[state.offset + i]
		if s then
			local icon, iid = ProfitmancerAH.icon(s[5], s[1]); if iid and not s[5] then s[5] = iid end
			r.icon:SetTexture(icon)
			r.name:SetText(s[1])
			r.qty:SetText((s[3] or 0) > 0 and ("x" .. s[3]) or "|cff9e9e9ex?|r")
			r.amount:SetText(money(s[2]))
			r.when:SetText(when(s[4]))
			r.data = s
			r:Show()
		else
			r.data = nil
			r:Hide()
		end
	end
	panel.empty:SetShown(#list == 0)
	panel.page:SetText(#list > ROWS and T.rows:format(state.offset + 1, math.min(#list, state.offset + ROWS), #list) .. " · " .. T.wheel or "")
	for k, b in pairs(panel.pb) do
		if k == state.period then b:LockHighlight() else b:UnlockHighlight() end
	end
end

local function build()
	if panel then return end
	panel = CreateFrame("Frame", "ProfitmancerSalesPanel", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	panel:SetSize(380, 470); panel:SetFrameStrata("HIGH"); panel:SetClampedToScreen(true)
	panel:EnableMouse(true); panel:SetMovable(true); panel:RegisterForDrag("LeftButton")
	panel:SetScript("OnDragStart", function(self) if not self.docked then self:StartMoving() end end)
	panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
	if panel.SetBackdrop then
		panel:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } })
		panel:SetBackdropBorderColor(0.6, 0.6, 0.6)
	end
	local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal"); title:SetPoint("TOPLEFT", 14, -12); title:SetText(T.title)
	local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton"); close:SetPoint("TOPRIGHT", 2, 2)
	panel.titleFS, panel.closeB = title, close
	close:SetScript("OnClick", function() panel:Hide(); styleBtn(false) end)

	-- period buttons + search
	panel.pb = {}
	local prev
	for _, p in ipairs({ { 1, T.p1 }, { 7, T.p7 }, { 30, T.p30 }, { 0, T.pAll } }) do
		local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		b:SetSize(48, 20); b:SetText(p[2])
		if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 12, -34) end
		b:SetScript("OnClick", function() state.period = p[1]; state.offset = 0; render() end)
		panel.pb[p[1]] = b; prev = b
	end
	local sb = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
	sb:SetSize(130, 20); sb:SetPoint("TOPRIGHT", -14, -34); sb:SetAutoFocus(false)
	sb:SetScript("OnTextChanged", function(self) state.query = self:GetText() or ""; state.offset = 0; render() end)
	sb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	local ph = sb:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); ph:SetPoint("LEFT", 4, 0); ph:SetText(T.search)
	sb:HookScript("OnTextChanged", function(self) ph:SetShown((self:GetText() or "") == "") end)

	panel.sum1 = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); panel.sum1:SetPoint("TOPLEFT", 14, -64)
	panel.sum2 = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); panel.sum2:SetPoint("TOPLEFT", 14, -80); panel.sum2:SetPoint("RIGHT", -14, 0); panel.sum2:SetJustifyH("LEFT")

	-- framed area for the list, like the auction house's own insets
	local inset = CreateFrame("Frame", nil, panel, BackdropTemplateMixin and "BackdropTemplate" or nil)
	inset:SetPoint("TOPLEFT", 8, -94); inset:SetPoint("BOTTOMRIGHT", -8, 26)
	if inset.SetBackdrop then
		inset:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
		inset:SetBackdropColor(0.07, 0.055, 0.04, 0.85); inset:SetBackdropBorderColor(0.55, 0.44, 0.24)
	end
	panel.inset = inset
	for i = 1, MAXROWS do
		local r = CreateFrame("Button", nil, panel)
		r:SetHeight(ROW_H); r:SetPoint("TOPLEFT", 12, -98 - (i - 1) * ROW_H); r:SetPoint("RIGHT", -12, 0); r:SetFrameLevel(inset:GetFrameLevel() + 2)
		local hl = r:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints(); hl:SetColorTexture(1, 1, 1, 0.08)
		if i % 2 == 0 then local bg = r:CreateTexture(nil, "BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(1, 1, 1, 0.03) end
		r.icon = r:CreateTexture(nil, "ARTWORK"); r.icon:SetSize(26, 26); r.icon:SetPoint("LEFT", 4, 0)
		r.when = r:CreateFontString(nil, "OVERLAY", "GameFontDisable"); r.when:SetPoint("RIGHT", -4, 0); r.when:SetWidth(60); r.when:SetJustifyH("RIGHT")
		r.amount = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); r.amount:SetPoint("RIGHT", r.when, "LEFT", -10, 0); r.amount:SetWidth(120); r.amount:SetJustifyH("RIGHT")
		r.qty = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); r.qty:SetPoint("RIGHT", r.amount, "LEFT", -16, 0); r.qty:SetWidth(60); r.qty:SetJustifyH("RIGHT")
		r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0); r.name:SetPoint("RIGHT", r.qty, "LEFT", -8, 0)
		r.name:SetJustifyH("LEFT"); r.name:SetWordWrap(false)
		r:SetScript("OnEnter", function(self)
			local s = self.data; if not s then return end
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			if s[5] then pcall(GameTooltip.SetItemByID, GameTooltip, s[5]) else GameTooltip:AddLine(s[1], 1, 1, 1) end
			GameTooltip:AddLine(" ")
			GameTooltip:AddDoubleLine(date(FR and "%d/%m/%Y %H:%M" or "%m/%d/%Y %H:%M", s[4]), money(s[2]), 0.8, 0.8, 0.8, 0.24, 0.77, 0.43)
			if (s[3] or 0) > 1 then GameTooltip:AddDoubleLine("x" .. s[3], money(s[2] / s[3]) .. " " .. T.each, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8) end
			GameTooltip:Show()
		end)
		r:SetScript("OnLeave", function() GameTooltip:Hide() end)
		rows[i] = r
	end
	panel:EnableMouseWheel(true)
	panel:SetScript("OnMouseWheel", function(_, d) state.offset = state.offset - d * 3; render() end)
	panel.empty = panel.inset:CreateFontString(nil, "OVERLAY", "GameFontDisable"); panel.empty:SetPoint("TOPLEFT", 20, -110); panel.empty:SetDrawLayer("OVERLAY", 7); panel.empty:SetPoint("RIGHT", -20, 0)
	panel.empty:SetJustifyH("LEFT"); panel.empty:SetText(T.empty)
	panel.page = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); panel.page:SetPoint("BOTTOM", 0, 8)
	panel:SetScript("OnShow", render)
	panel:Hide()
	ProfitmancerAH.own(panel)
	ProfitmancerAH.view(panel, function() styleBtn(false) end)
end

local function dock()
	ProfitmancerAH.dock(panel)
	local h = panel.docked and ProfitmancerAH.host() and ProfitmancerAH.host():GetHeight() - 56 or 480
	ROWS = math.max(6, math.min(MAXROWS, math.floor((h - 120) / ROW_H)))
	for i, r in ipairs(rows) do if i > ROWS then r:Hide() end end
end

-- The "Sales" tab-styled button, after the auction house tabs (placed by AHTab.lua, with Shopping after it)
function styleBtn(open) ProfitmancerAH.style(ahBtn, open) end

local function toggle(show)
	build()
	if show == nil then show = not panel:IsShown() end
	if show then
		ProfitmancerAH.hideAll(panel)
		dock(); panel:Show(); render()
	else panel:Hide() end
	styleBtn(show)
end

local function makeButton()
	if ahBtn or not ProfitmancerAH.host() then return end
	ahBtn = ProfitmancerAH.button("ProfitmancerSalesButton", "Interface\\Icons\\INV_Misc_Coin_02", T.btn, T.btnTip, nil, function()
		ProfitmancerDB.salesSeen = true
		if ahBtn.pulse then ahBtn.pulse:Stop(); ahBtn.glow:Hide() end
		toggle()
	end)
	-- soft purple glow that pulses until the panel has been opened once
	local glow = ahBtn:CreateTexture(nil, "BACKGROUND")
	glow:SetPoint("TOPLEFT", -6, 6); glow:SetPoint("BOTTOMRIGHT", 6, -6)
	glow:SetColorTexture(0.71, 0.55, 1, 0.35); glow:SetBlendMode("ADD")
	local ag = glow:CreateAnimationGroup(); ag:SetLooping("BOUNCE")
	local fade = ag:CreateAnimation("Alpha"); fade:SetFromAlpha(0.15); fade:SetToAlpha(0.9); fade:SetDuration(1.1); fade:SetSmoothing("IN_OUT")
	ahBtn.glow, ahBtn.pulse = glow, ag
	ProfitmancerAH.register(ahBtn)
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("AUCTION_HOUSE_SHOW"); ev:RegisterEvent("AUCTION_HOUSE_CLOSED")
ev:SetScript("OnEvent", function(_, e)
	if e == "AUCTION_HOUSE_SHOW" then
		pcall(makeButton)
		if ahBtn then
			if ProfitmancerDB.salesSeen then ahBtn.pulse:Stop(); ahBtn.glow:Hide() else ahBtn.glow:Show(); ahBtn.pulse:Play() end
			styleBtn(false)
		end
	elseif panel and panel.docked then
		panel:Hide(); styleBtn(false)
	end
end)

ProfitmancerSales = {
	toggle = function() toggle() end,
	hide = function() if panel and panel:IsShown() then panel:Hide(); styleBtn(false) end end,
	refresh = function() if panel and panel:IsShown() then render() end end,
}
