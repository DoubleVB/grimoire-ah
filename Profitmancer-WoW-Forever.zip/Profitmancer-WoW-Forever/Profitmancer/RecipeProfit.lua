-- Profitmancer: profit or loss of each recipe, right in the list of the profession window (green = profit, red = loss).
-- The rows are found by their text (the recipe names the game gives), so it works with the window's own layout.
local function api() return ProfitmancerAPI end

local GetItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
local function plain(t) return (tostring(t or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("%s*%[%d+%]$", ""):gsub("^%s+", ""):gsub("%s+$", "")) end

-- recipe name -> product item id: from the profession window's API when there is one, and from the item names of every recipe Profitmancer knows
local staticMap, staticAt = {}, 0
local function addStatic(m)
	local a = ProfitmancerAPI
	if a and a.products and (GetTime() - staticAt > 5 or next(staticMap) == nil) then
		staticAt = GetTime()
		for _, id in ipairs(a.products()) do
			local n = GetItemInfo(id)
			if n then staticMap[n] = id
			elseif C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
		end
	end
	for n, id in pairs(staticMap) do if m[n] == nil then m[n] = id end end
end
local function recipeMap()
	local m = {}
	if GetNumTradeSkills and GetTradeSkillInfo and GetTradeSkillItemLink then
		for i = 1, GetNumTradeSkills() or 0 do
			local name, kind = GetTradeSkillInfo(i)
			if name and kind ~= "header" and kind ~= "subheader" then
				local link = GetTradeSkillItemLink(i)
				local id = link and tonumber(link:match("item:(%d+)"))
				if id then m[name] = id end
			end
		end
	end
	if GetNumCrafts and GetCraftInfo and GetCraftItemLink and CraftFrame and CraftFrame:IsShown() then
		for i = 1, GetNumCrafts() or 0 do
			local name, _, kind = GetCraftInfo(i)
			if name and kind ~= "header" then
				local link = GetCraftItemLink(i)
				local id = link and tonumber(link:match("item:(%d+)"))
				if id then m[name] = id end
			end
		end
	end
	local U = C_TradeSkillUI
	if U and U.GetAllRecipeIDs and U.GetRecipeInfo then
		local ok, ids = pcall(U.GetAllRecipeIDs)
		for _, rid in ipairs(ok and ids or {}) do
			local info = U.GetRecipeInfo(rid)
			if info and info.name and m[info.name] == nil then
				local item
				if U.GetRecipeOutputItemData then local ok2, out = pcall(U.GetRecipeOutputItemData, rid); item = ok2 and out and out.itemID end
				if not item and U.GetRecipeSchematic then local ok3, sch = pcall(U.GetRecipeSchematic, rid, false); item = ok3 and sch and sch.outputItemID end
				if item then m[info.name] = item end
			end
		end
	end
	addStatic(m)
	-- Recipes named differently from what they make (Smelt Copper -> Copper Bar, Transmute: Iron to Gold -> Gold Bar)
	m.__alias = function(name)
		local x = name:match("^Smelt (.+)$")
		if x then return m[x .. " Bar"] or m[x] end
		local b = name:match("^Transmute: .- to (.+)$") or name:match("^Transmute: (.+)$")
		if b then return m[b .. " Bar"] or m["Essence of " .. b] or m[b] end
	end
	return m
end
local function lookup(m, name)
	local id = m[name]
	if id == nil and m.__alias and type(id) ~= "number" then id = m.__alias(name) end
	return type(id) == "number" and id or nil
end

-- every visible frame of the window that shows one of these names
local rowsCache, lastScan = {}, 0
local function scan(root, names)
	local found = {}
	local function walk(f, depth)
		if depth > 9 or not f.IsShown or not f:IsShown() then return end
		local h = f.GetHeight and f:GetHeight() or 0
		if f.GetRegions and h > 8 and h <= 40 then -- list rows only (not the big recipe title in the details panel)
			for _, r in ipairs({ f:GetRegions() }) do
				if r.GetObjectType and r:GetObjectType() == "FontString" and r ~= rawget(f, "pfmProfit") then
					local t = r:GetText()
					if t and lookup(names, plain(t)) then found[#found + 1] = { f, r } break end
				end
			end
		end
		for _, c in ipairs({ f:GetChildren() }) do walk(c, depth + 1) end
	end
	walk(root, 0)
	return found
end

-- Short amount, one unit: +2.8g / -12s / -96c (po / pa / pc in French); the exact amount is in the recipe's tooltip
local FR = GetLocale() == "frFR"
local UG, US, UC = FR and "po" or "g", FR and "pa" or "s", FR and "pc" or "c"
local function money(c)
	local sign = c < 0 and "-" or "+"
	c = math.abs(c)
	local txt
	if c >= 1000000 then txt = math.floor(c / 10000 + 0.5) .. UG
	elseif c >= 10000 then
		local g = math.floor(c / 1000 + 0.5) / 10
		txt = (g == math.floor(g) and tostring(math.floor(g)) or tostring(g)) .. UG
		if FR then txt = txt:gsub("%.", ",") end
	elseif c >= 100 then txt = math.floor(c / 100 + 0.5) .. US
	else txt = math.floor(c + 0.5) .. UC end
	return sign .. txt
end

-- Caches: the name map is rebuilt when the window's list changes (or every 15 s), profits every 30 s (prices only change on a reload),
-- and the rows are looked for again only inside the list that holds them once it is known.
local mapCache, mapAt, mapDirty = nil, 0, true
local profitCache, profitAt = {}, 0
local listParent
local function names()
	if mapDirty or not mapCache or GetTime() - mapAt > 15 then mapCache, mapAt, mapDirty = recipeMap(), GetTime(), false end
	return mapCache
end
local function profitOf(id)
	if GetTime() - profitAt > 30 then profitCache, profitAt = {}, GetTime() end
	local v = profitCache[id]
	if v == nil then
		local a = api()
		v = (a and a.profit(id)) or false
		profitCache[id] = v
	end
	return v or nil
end

local function update(root, rescan)
	if not api() then return end
	local m = names()
	if next(m) == nil then return end
	if rescan and GetTime() - lastScan > 1 then
		lastScan = GetTime()
		local within = (listParent and listParent:IsShown()) and listParent or root
		rowsCache = scan(within, m)
		if #rowsCache == 0 and within ~= root then rowsCache = scan(root, m) end
		local p = rowsCache[1] and rowsCache[1][1]:GetParent()
		if p and p ~= root then listParent = p end
	end
	for _, fr in ipairs(rowsCache) do
		local f, label = fr[1], fr[2]
		local t = label:GetText()
		if t ~= rawget(f, "pfmText") then -- only when the row shows another recipe (scrolling, folding)
			f.pfmText = t
			local id = t and lookup(m, plain(t))
			local fs = rawget(f, "pfmProfit")
			if not fs then
				fs = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
				fs:SetPoint("RIGHT", f, "RIGHT", -8, 0)
				fs:SetJustifyH("RIGHT")
				f.pfmProfit = fs
			end
			local pr = id and profitOf(id)
			-- the recipe name stops before the profit ("Draught of Greater Water Brea...") so they never overlap
			label:SetWordWrap(false)
			if pr then
				fs:SetText((pr >= 0 and "|cff1eff00" or "|cffff5a4a") .. money(pr) .. "|r")
				fs:Show()
				label:SetPoint("RIGHT", fs, "LEFT", -6, 0)
			else
				fs:Hide()
				label:SetPoint("RIGHT", f, "RIGHT", -6, 0)
			end
		end
	end
end

-- Runs only while a profession window is open
local ticker = CreateFrame("Frame")
ticker:Hide()
local acc = 0
-- Every frame: compare the few visible rows' text (cheap, so scrolling updates at once); look for rows again every second
ticker:SetScript("OnUpdate", function(self, dt)
	acc = acc + dt
	local rescan = acc > 1
	if rescan then acc = 0 end
	local any = false
	for _, n in ipairs({ "ProfessionsFrame", "TradeSkillFrame", "CraftFrame" }) do
		local f = _G[n]
		if f and f:IsShown() then any = true; pcall(update, f, rescan) end
	end
	if not any then self:Hide() end
end)
local ev = CreateFrame("Frame")
for _, e in ipairs({ "TRADE_SKILL_SHOW", "CRAFT_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_UPDATE", "CRAFT_UPDATE" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e)
	mapDirty = true
	if e == "TRADE_SKILL_SHOW" or e == "CRAFT_SHOW" then lastScan = 0; acc = 2; for _, fr in ipairs(rowsCache) do fr[1].pfmText = nil end end
	ticker:Show()
end)

-- /pfm debug recipes: what Profitmancer sees in the open profession window
function ProfitmancerRecipeProfitDebug()
	local f = TradeSkillFrame or CraftFrame or ProfessionsFrame
	local m = recipeMap()
	local n = 0 for _ in pairs(m) do n = n + 1 end
	local rows = f and f:IsShown() and scan(f, m) or {}
	print("|cffb48cffProfitmancer|r debug: window " .. tostring(f and f:GetName()) .. " shown=" .. tostring(f and f:IsShown())
		.. " · API classic=" .. tostring(GetNumTradeSkills ~= nil) .. " modern=" .. tostring(C_TradeSkillUI ~= nil)
		.. " · names known=" .. n .. " · rows found=" .. #rows .. " · reagents label=" .. tostring(_G.TradeSkillReagentLabel ~= nil))
	for i = 1, math.min(3, #rows) do print("   row: " .. tostring(rows[i][2]:GetText()) .. " h=" .. math.floor(rows[i][1]:GetHeight() or 0)) end
end
