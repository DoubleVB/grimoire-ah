﻿# Grimoire updater: downloads the latest price file of your auction house into the WoW Forever addon.
# Run every hour by the "Grimoire - WoW Forever prices" scheduled task. Log: %LOCALAPPDATA%\Grimoire\update.log
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Home2 = Join-Path $env:LOCALAPPDATA "Grimoire"
$Log = Join-Path $Home2 "update.log"
function Log($m) { "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" | Add-Content -Encoding UTF8 $Log; Write-Host $m }
try {
  $cfg = Get-Content (Join-Path $Home2 "config.json") -Raw | ConvertFrom-Json
  $dir = Join-Path $cfg.wow "Interface\AddOns\Grimoire"
  if (-not (Test-Path $dir)) { throw "Addon folder missing: $dir" }
  $url = "https://raw.githubusercontent.com/DoubleVB/grimoire-ah/data/ah/$($cfg.key)/GrimoireData.lua?t=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
  $tmp = Join-Path $Home2 "GrimoireData.tmp"
  Invoke-WebRequest -UseBasicParsing $url -OutFile $tmp
  $head = Get-Content $tmp -TotalCount 3 -Encoding UTF8
  if (-not ($head -join "`n").Contains("GrimoireData={")) { throw "Unexpected file content" }
  Move-Item $tmp (Join-Path $dir "GrimoireData.lua") -Force
  Log "OK  $($cfg.label)  $($head[0])"
  # keep the log short
  $lines = Get-Content $Log -Encoding UTF8; if ($lines.Count -gt 300) { $lines[-200..-1] | Set-Content -Encoding UTF8 $Log }
} catch { Log "ERROR  $($_.Exception.Message)"; exit 1 }
