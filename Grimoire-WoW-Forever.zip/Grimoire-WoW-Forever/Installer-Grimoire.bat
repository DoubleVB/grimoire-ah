@echo off
title Grimoire - WoW Forever
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Grimoire.ps1"
echo.
pause
